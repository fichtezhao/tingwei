from sqlite3 import *

db = connect('sportsclub.db')
c = db.cursor()                                                             #[1m] 5.1 db connect + cursor + commit + close

c.execute('''INSERT INTO Session(Id, Date, Sport) \
          VALUES(?,?,?)''', (2504, '2025-02-14', 'Lawn Bowls'))                     #[1m] 5.1 insert session

f = open('SessionId_S2504_ATTENDANCE.TXT')                                  #[1m] 5.1 open close file + strip   split
data = f.readlines()
for line in data[1:]:
    memberid, sessionid, status = line.strip().split(',')                   
    c.execute('''INSERT INTO Attendance(MemberId, SessionId, Status) \
              VALUES(?,?,?)''', (memberid, int(sessionid), status))                      #[1m] 5.1 correct insert

f.close()
db.commit()
db.close()