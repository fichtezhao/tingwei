from sqlite3 import *
from flask import *

app = Flask(__name__)                                       

@app.route('/')                                             
def index():
    return render_template('index.html')                    #[1m] 5.2 correct index fn
                                                            #[1m] 5.2 correct index.html
    
@app.route('/members')
def members():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Member.Class, Member.Name 
              FROM Member''')                               
    data = c.fetchall()                                     #[1m] 5.2 correct select + fetch
    db.close()
    return render_template('members.html', data = data)     #[1m] 5.2 correct render with data
                                                            #[1m] 5.2 correct members.html




app.run('127.0.0.1', 5000, debug = True)                    #[1m] 5.2 correct import, app, run