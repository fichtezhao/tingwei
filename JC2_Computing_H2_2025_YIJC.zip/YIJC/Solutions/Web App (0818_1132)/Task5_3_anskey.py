from sqlite3 import *
from flask import *

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/members')
def members():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Member.Class, Member.Name 
              FROM Member''')
    data = c.fetchall()
    db.close()
    return render_template('members.html', data = data)

@app.route('/attendance', methods = ['POST'])                           #[1m] 5.3 correct form on index.html
def attendance():
    sport = request.form.get('sport')                                   #[1m] 5.3 correct form request
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Session.Date, Member.Name, Attendance.Status
              FROM Session, Member, Attendance
              WHERE Attendance.MemberId = Member.Id
              AND Attendance.SessionId = Session.Id
              AND Session.Sport = ?''', (sport,))                       #[1m] 5.3 correct query + fetchall
    attendance = c.fetchall()
    db.close()
    return render_template('attendance.html', att = attendance, sport = sport)
                                                                        #[1m] 5.3 correct table + jinja on attendance.html


app.run('127.0.0.1', 5000, debug = True)