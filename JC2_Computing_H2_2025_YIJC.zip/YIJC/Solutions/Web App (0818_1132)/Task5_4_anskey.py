from sqlite3 import *
from flask import *

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/members')
def members():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Member.Class, Member.Name 
              FROM Member''')
    data = c.fetchall()
    db.close()
    return render_template('members.html', data = data)

@app.route('/attendance', methods = ['POST'])
def attendance():
    sport = request.form.get('sport')

    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Session.Date, Member.Name, Attendance.Status
              FROM Session, Member, Attendance
              WHERE Attendance.MemberId = Member.Id
              AND Attendance.SessionId = Session.Id
              AND Session.Sport = ?''', (sport,))
    attendance = c.fetchall()

    db.close()
    return render_template('attendance.html', att = attendance, sport = sport)

@app.route('/absent')
def absent():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Member.Name, Member.Class, Session.Date     
              FROM Member, Session, Attendance
              WHERE Attendance.MemberId = Member.Id
              AND Attendance.SessionId = Session.Id
              AND Attendance.Status = 0
              SORT BY Member.Name''')                               #[1m] 5.4 correct sql statement
                                                                        #[1m] 5.4 correct join + sort
    data = c.fetchall()
    db.close()
    return render_template('absent.html', data = data)                  #[1m] 5.4 correct table + jinja on absent.html          



app.run('127.0.0.1', 5000, debug = True)