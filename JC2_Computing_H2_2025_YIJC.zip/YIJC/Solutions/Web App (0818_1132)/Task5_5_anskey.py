from sqlite3 import *
from flask import *

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/members')
def members():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Member.Class, Member.Name 
              FROM Member''')
    data = c.fetchall()
    db.close()
    return render_template('members.html', data = data)

@app.route('/attendance', methods = ['POST'])
def attendance():
    sport = request.form.get('sport')

    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Session.Date, Member.Name, Attendance.Status
              FROM Session, Member, Attendance
              WHERE Attendance.MemberId = Member.Id
              AND Attendance.SessionId = Session.Id
              AND Session.Sport = ?''', (sport,))
    attendance = c.fetchall()

    db.close()
    return render_template('attendance.html', att = attendance, sport = sport)

@app.route('/absent')
def absent():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Member.Name, Member.Class, Session.Date
              FROM Member, Session, Attendance
              WHERE Attendance.MemberId = Member.Id
              AND Attendance.SessionId = Session.Id
              AND Attendance.Status = 0''')
    data = c.fetchall()
    db.close()
    return render_template('absent.html', data = data)

@app.route('/mark')
def mark():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT * From Member ORDER BY Member.Class''')          
    members = c.fetchall()
    # members = []
    # for line in data:
    #     members.append([line[0], line[1], line[2]])                                                             #[1m] 5.5 correct member query + data processing
    db.close()
    return render_template('mark.html', members = members)                                                      #[1m] 5.5 mark.html correct text input + sport selection
                                                                                                                #[1m] 5.5 mark.html correct checkbox values

@app.route('/success', methods = ['POST'])                                                                      #[1m] 5.5 success route correct methods
def success():
    sport = request.form.get('sport')
    date = request.form.get('date')
    present = request.form.getlist('present')
    print(present)
    db = connect('sportsclub.db')
    c = db.cursor()

    c.execute('''INSERT INTO Session(Date, Sport)
              VALUES(?,?)''', (date, sport))                                                                    #[1m] 5.5 success route create session
    db.commit()

    c.execute('''SELECT Member.Id from Member''')
    data = c.fetchall()
    members = []
    for item in data:
        members.append(item[0])
    print(members)

    c.execute('''SELECT Session.Id FROM Session WHERE Session.date = ? and Session.Sport = ?''', (date, sport))  #[1m] 5.5 retrive session number
    session_id = c.fetchone()[0]
    for memberid in members:
        if memberid in present:
            c.execute('''INSERT INTO Attendance(MemberId, SessionId, Status) 
                  VALUES(?,?,?)''', (memberid, session_id, '1'))
        else:
            c.execute('''INSERT INTO Attendance(MemberId, SessionId, Status) 
                  VALUES(?,?,?)''', (memberid, session_id, '0'))                                                  #[1m] 5.5 insert into attendance table
    db.commit()
    db.close()
    return render_template('success.html')
    


app.run('127.0.0.1', 5000, debug = True)