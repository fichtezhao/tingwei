from sqlite3 import *

db = connect('sportsclub.db')
c = db.cursor()

c.execute('''INSERT INTO Session(Id, Date, Sport) \
          VALUES(?,?,?)''', ('S2004', '2025-02-14', 'Lawnbowls'))          #[1m] 4.1 insert session

f = open('S2004_ATTENDANCE.TXT')                                            #[1m] 4.1 open close file - strip and split
data = f.readlines()
for line in data:
    memberid, sessionid, status = line.strip().split(',')                   
    c.execute('''INSERT INTO Attendance(MemberId, SessionId, Status) \
              VALUES(?,?,?)''', (memberid, sessionid, status))              #[1m] 4.1 correct insert

f.close()
db.commit()
db.close()