from flask import *
from sqlite3 import *

app = Flask(__name__)                           #[1m] 4.2 correct import and app start + run

@app.route('/')
def index():
    return render_template('index.html')        #[1m] 4.2 correct base route + pass other routes

@app.route('/lawnbowls')
def lawnbowls():
    pass

@app.route('/pickleball')
def pickleball():
    pass

@app.route('/tchoukball')
def tchoukball():
    pass

@app.route('/best_att')
def best_att():
    pass

@app.route('/teacher')
def teacher():
    pass

app.run(debug = False, port = 5000)     #[1m] 4.2correct html structure-->
                                        #[1m] 4.2 correct url routes-->