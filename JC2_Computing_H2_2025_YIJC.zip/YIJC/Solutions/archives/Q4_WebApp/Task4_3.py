from flask import *
from sqlite3 import *

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/lawnbowls')
def lawnbowls():
    db = connect('sportsclub.db')                                           #[1m] 4.3 correct connection cursor close
    c = db.cursor()
    c.execute('''SELECT Session.Date, Member.FullName, Attendance.Status
FROM Session, Member, Attendance                                            
WHERE Member.Id = Attendance.MemberId
AND Session.Id = Attendance.SessionId
AND Member.Sport = 'Lawnbowls'
ORDER by Session.Date''')                                                   #[1m] 4.3 correct constraints + order
    data = c.fetchall()                                                     #[1m] 4.3 correct fetchall
    db.close()
    return render_template('lawnbowls.html', data = data)                   #[1m] 4.3 correct render + bundle
                                                                            #[1m] 4.3 html correct loop + jinja
                                                                            #[1m] 4.3 repeat for 2 other sports
@app.route('/pickleball')
def pickleball():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Session.Date, Member.FullName, Attendance.Status
FROM Session, Member, Attendance
WHERE Member.Id = Attendance.MemberId
AND Session.Id = Attendance.SessionId
AND Member.Sport = 'Pickleball'
ORDER by Session.Date''')
    data = c.fetchall()
    db.close()
    return render_template('pickleball.html', data = data)

@app.route('/tchoukball')
def tchoukball():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Session.Date, Member.FullName, Attendance.Status
FROM Session, Member, Attendance
WHERE Member.Id = Attendance.MemberId
AND Session.Id = Attendance.SessionId
AND Member.Sport = 'Tchoukball'
ORDER by Session.Date''')
    data = c.fetchall()
    db.close()
    return render_template('Tchoukball.html', data = data)

@app.route('/best_att')
def best_att():
    pass

@app.route('/teacher')
def teacher():
    pass

app.run(debug = False, port = 5000)