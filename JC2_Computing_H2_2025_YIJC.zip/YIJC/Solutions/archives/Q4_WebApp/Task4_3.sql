SELECT Session.Date, Member.FullName, Attendance.Status
FROM Session, Member, Attendance
WHERE Member.Id = Attendance.MemberId
AND Session.Id = Attendance.SessionId
AND Member.Sport = 'Pickleball'
ORDER by Session.Date