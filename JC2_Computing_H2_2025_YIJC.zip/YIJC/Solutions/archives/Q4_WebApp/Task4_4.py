from flask import *
from sqlite3 import *

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/lawnbowls')
def lawnbowls():
    db = connect('sportsclub.db')                                           
    c = db.cursor()
    c.execute('''SELECT Session.Date, Member.FullName, Attendance.Status
FROM Session, Member, Attendance                                            
WHERE Member.Id = Attendance.MemberId
AND Session.Id = Attendance.SessionId
AND Member.Sport = 'Lawnbowls'
ORDER by Session.Date''')                                                   
    data = c.fetchall()
    db.close()
    return render_template('lawnbowls.html', data = data)                   
                                                                            
                                                                            
@app.route('/pickleball')
def pickleball():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Session.Date, Member.FullName, Attendance.Status
FROM Session, Member, Attendance
WHERE Member.Id = Attendance.MemberId
AND Session.Id = Attendance.SessionId
AND Member.Sport = 'Pickleball'
ORDER by Session.Date''')
    data = c.fetchall()
    db.close()
    return render_template('pickleball.html', data = data)

@app.route('/tchoukball')
def tchoukball():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Session.Date, Member.FullName, Attendance.Status
FROM Session, Member, Attendance
WHERE Member.Id = Attendance.MemberId
AND Session.Id = Attendance.SessionId
AND Member.Sport = 'Tchoukball'
ORDER by Session.Date''')
    data = c.fetchall()
    db.close()
    return render_template('Tchoukball.html', data = data)

@app.route('/best_att')
def best_att():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Member.FullName, Member.Sport
FROM Member, Attendance
WHERE Member.Id = Attendance.MemberId
GROUP BY Attendance.MemberId
HAVING SUM(Attendance.Status) = 3
ORDER BY Member.FullName''')
                                                        #[1m] 4.4 Correct WHERE condition (Blank A)
                                                        #[1m] 4.4 Correct GROUP BY conditon (Blank B)
                                                        #[1m] 4.4 Correct SUM = 3 (Blank C)
                                                        #[1m] 4.4 Correct ORDER BY (Blank D)
                                                            
    data = c.fetchall()     
    db.close()
    return render_template('best_att.html', data = data)    #[1m] correct html + jinja

@app.route('/teacher')
def teacher():
    pass

app.run(debug = False, port = 5000)