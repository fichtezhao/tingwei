SELECT Member.FullName, Member.Sport
FROM Member, Attendance
WHERE Member.Id = Attendance.MemberId
GROUP BY Attendance.MemberId
HAVING SUM(Attendance.Status) = 3
ORDER BY Member.FullName