from flask import *
from sqlite3 import *

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/lawnbowls')
def lawnbowls():
    db = connect('sportsclub.db')                                           
    c = db.cursor()
    c.execute('''SELECT Session.Date, Member.FullName, Attendance.Status
FROM Session, Member, Attendance                                            
WHERE Member.Id = Attendance.MemberId
AND Session.Id = Attendance.SessionId
AND Member.Sport = 'Lawn Bowls'
ORDER by Session.Date''')                                                   
    data = c.fetchall()
    db.close()
    return render_template('lawnbowls.html', data = data)                   
                                                                            
                                                                            
@app.route('/pickleball')
def pickleball():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Session.Date, Member.FullName, Attendance.Status
FROM Session, Member, Attendance
WHERE Member.Id = Attendance.MemberId
AND Session.Id = Attendance.SessionId
AND Member.Sport = 'Pickleball'
ORDER by Session.Date''')
    data = c.fetchall()
    db.close()
    return render_template('pickleball.html', data = data)

@app.route('/tchoukball')
def tchoukball():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Session.Date, Member.FullName, Attendance.Status
FROM Session, Member, Attendance
WHERE Member.Id = Attendance.MemberId
AND Session.Id = Attendance.SessionId
AND Member.Sport = 'Tchoukball'
ORDER by Session.Date''')
    data = c.fetchall()
    db.close()
    return render_template('Tchoukball.html', data = data)

@app.route('/best_att')
def best_att():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Member.FullName, Member.Sport
FROM Member, Attendance
WHERE Member.Id = Attendance.MemberId
GROUP BY Attendance.MemberId
HAVING SUM(Attendance.Status) = 3
ORDER BY Member.FullName''')
                                                            
    data = c.fetchall()     
    db.close()
    return render_template('best_att.html', data = data)    

@app.route('/teacher')
def teacher():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Member.FullName, Member.Sport, Session.date
FROM Member, Session, Attendance
WHERE Member.Id = Attendance.MemberId
AND Session.Id = Attendance.SessionId
AND Attendance.Status = 0''')                                   #[1m] 4.5 correct sql to retrieve absent students
    data = c.fetchall()
    db.close()
    return render_template('teacher.html', data = data)         
                                                                #[1m] 4.5 correct display of info (FullName, Sport, Date, MC fields)
                                                                #[1m] 4.5 correct form (password field)
                                                                #[1m] 4.5 correct checkbox (values set to FullName)

@app.route('/submit', methods = ['POST'])
def submit():
    password = request.form.get('pw')                           #[1m] 4.5 retrieve form details
    print(password)
    if password != 'teacher123':            
        return render_template('index.html')                    #[1m] 4.5 correct password check
    else:
        names = request.form.getlist('MC')
        print(names)
        db = connect('sportsclub.db')
        c = db.cursor()
        for name in names:
            print(name)
            c.execute('''SELECT Member.Id FROM Member \
                      WHERE Member.FullName = ?''', (name,))
            memberid = c.fetchone()[0]
            c.execute('''UPDATE ATTENDANCE SET Status = 'MC' \
                      WHERE Attendance.MemberId = ? \
                      AND Attendance.Status = '0' ''', (memberid,)) #[1m] 4.5 correct db updates
        db.commit()
        db.close()                                                  #[1m] 4.5 db open, close, commit
        return render_template('mc.html', names = names)
            

app.run(debug = False, port = 5000)