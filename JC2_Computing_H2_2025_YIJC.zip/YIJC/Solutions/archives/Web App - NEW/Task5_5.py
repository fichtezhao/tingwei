from flask import *
from sqlite3 import *

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/members')
def members():
    db = connect('sportsclub.db')                                           
    c = db.cursor()
    c.execute('''SELECT * FROM Member ORDER by Class''')                                                   
    data = c.fetchall()
    db.close() 

    return render_template('members.html', data=data)  

@app.route('/attendance', methods=['POST'])
def attendance():
    sports = request.form.get("sports")

    db = connect('sportsclub.db')                                           
    c = db.cursor()
    c.execute('''SELECT Session.Date, Member.Name, Attendance.Status
FROM Session, Member, Attendance                                            
WHERE Member.Id = Attendance.MemberId
AND Session.Id = Attendance.SessionId
AND Session.Sport = ?
ORDER by Session.Date''', (sports,))                                                   
    data = c.fetchall()
    db.close()

    return render_template('attendance.html', sports=sports, data = data)    


@app.route('/absent')
def absent():
    db = connect('sportsclub.db')
    c = db.cursor()
    c.execute('''SELECT Member.Name, Class, Session.date
FROM Member, Session, Attendance
WHERE Member.Id = Attendance.MemberId
AND Session.Id = Attendance.SessionId
AND Attendance.Status = 0
ORDER by Member.Name''')                                   #[1m] 4.5 correct sql to retrieve absent students
    data = c.fetchall()
    db.close()
    return render_template('absent.html', data = data)  


@app.route('/mark')
def mark():
    db = connect('sportsclub.db')                                           
    c = db.cursor()
    c.execute('''SELECT * FROM Member ORDER by Class''')                                                   
    data = c.fetchall()
    db.close() 

    return render_template('mark.html', data=data)  


@app.route('/update', methods = ['POST'])
def update():

    date = request.form.get('date')
    sport = request.form.get('sport')
    IDs = request.form.getlist('Present')
    print(IDs)
    
    db = connect('sportsclub.db')
    c = db.cursor()

    #session id is autoincrement
    c.execute('''INSERT INTO Session(Date, Sport) VALUES(?,?)''', (date, sport))
    db.commit()

    c.execute('''SELECT Id FROM Session WHERE Date=? AND Sport=?''', (date, sport))
    sessionID = c.fetchone()
    
    c.execute('''SELECT Id FROM Member''')
    memberid = c.fetchall()
    print(memberid)
    for ID in memberid:
        if ID[0] in IDs:
            status = '1'
        else:
            status = '0'
        c.execute('''INSERT INTO Attendance(MemberId, SessionId, Status) VALUES(?,?,?)''', (ID[0], sessionID[0], status))

    db.commit()
    db.close()      
    return render_template('success.html')

app.run(debug = False, port = 5000)
